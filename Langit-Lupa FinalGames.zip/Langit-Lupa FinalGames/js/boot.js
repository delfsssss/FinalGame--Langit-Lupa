bootGame = {
	create:function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
    	
		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    	game.scale.forceLascape = true;
    	game.scale.pageAlignHorizontally = true;
   		game.scale.pageAlignVertically = true;
    	game.world.setBounds(0,0,800,1200);

    	
    	game.state.start("preloadGame");
    	
    	
	},
		update: function () {
   		game.scale.pageAlignVertically = true;
    	game.scale.pageAlignHorizontally = true;
    	game.scale.setShowAll();
    	game.scale.refresh();
	}

}
preloadGame = {
	preload:function(){
	game.load.image('bg','img/sky.png');
    game.load.image('char2','img/char2.png');
    game.load.image("platform1","img/platform1.png");
    game.load.image("platform2","img/platform2.png");
    game.load.image("platform3","img/platform3.png");
    game.load.image("platform4","img/platform4.png");
    game.load.image("platform5","img/platform5.png");
    game.load.image("ulap1","img/ulap1.png");
    game.load.image("ulap2","img/ulap2.png");
    game.load.image("ulap3","img/ulap3.png");
    game.load.image("ulap4","img/ulap4.png");
    game.load.image("ulap5","img/ulap5.png");
    game.load.image('gameover','img/gameover.png');
    game.load.image('winner','img/winner.png');
    game.load.image("title","img/title.png");
    game.load.image('restart','img/restart.png',200,0);
    game.load.image('about1','img/about1.png');
    game.load.image('back','img/back.png');
    game.load.audio('music','audio/music.mp3');


    game.load.spritesheet("start","img/startbut.png",500,0);
    game.load.spritesheet("about","img/about.png",500,0);
    game.load.spritesheet("menu","img/menu.png",250,0);
    game.load.spritesheet('char2','img/char2.png',69,89);
    game.load.spritesheet('enemy','img/kalaban.png',62,75);
    game.load.spritesheet('enemy2','img/kalaban2.png',62,75);
    game.load.spritesheet('player2','img/player 2.png',67,180);
    game.load.spritesheet('pauseButton','img/pause.png',50,50);
    game.load.spritesheet('leftButton','img/leftbut.png',106,0);
    game.load.spritesheet('rightButton','img/rightbut.png',106,0);
    game.load.spritesheet('jumpButton','img/jumpbut1.png',106,0);

	},
	create:function(){
		game.state.start("menuGame");
	}
}
menuGame = {
	create:function(){
		titlepage = game.add.sprite(0,0, "title");
        startButton = game.add.button(400,450,'start',this.actionOnClick, this);
        aboutButton = game.add.button(400,650,'about',this.aboutOnClick, this);
        menu = game.add.sprite(100,350,"menu");

	},
	actionOnClick: function(){
        titlepage.visible =! startButton.visible;
        startButton.destroy();
        game.state.start("playGame");

    },
    aboutOnClick: function(){
            aboutpage=game.add.image(0,0,"about1");
            restartButton=game.add.button(50,70,"back",restartB,this);
            function restartB() {
            aboutpage.visible =! restartButton.visible;
            restartButton.destroy();

            //window.location.href=window.location.href;
            game.state.start("menuGame");
            }
           }
}
playGame = {
	create:function(){
	game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    game.scale.forceLascape = true;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;
    game.world.setBounds(0,0,350,620);
    
    game.physics.startSystem(Phaser.Physics.ARCADE);
    //game.scale.fullScreenScaleMode = Phaser.ScaleManager.EXACT_FIT;
    game.add.sprite(0,0,'bg');
    player = game.add.sprite(450,h/2,'char2');
    player2 = game.add.sprite(0,500,'enemy');
    player3 = game.add.sprite(0,250,'enemy2');


    scoreText = game.add.text(16, 16, 'Score: 0', {fontSize: '32px Arial', fill: '#FFFFFF'})
    gameOverText = game.add.text(w/2-100,h/2-50,"",{fontSize:'32px Arial',fill:"red"});

    platform1 = game.add.sprite(0,580,"platform1");
    game.physics.arcade.enable(platform1);
    platform1.body.immovable = true;

    platform2 = game.add.sprite(800,450,"platform2");
    game.physics.arcade.enable(platform2);
    platform2.body.immovable = true;

    platform3 = game.add.sprite(100,350,"platform3");
    game.physics.arcade.enable(platform3);
    platform3.body.immovable = true;

    platform4 = game.add.sprite(500,150,"platform4");
    game.physics.arcade.enable(platform4);
    platform4.body.immovable = true;

    platform5 = game.add.sprite(600,700,"platform5");
    game.physics.arcade.enable(platform5);
    platform5.body.immovable = true;

    ulap1 = game.add.sprite(50,500,"ulap1");
    game.physics.arcade.enable(ulap1);
    ulap1.body.immovable = true;

    ulap2 = game.add.sprite(750,615,"ulap2");
    game.physics.arcade.enable(ulap2);
    ulap2.body.immovable = true;

    ulap3 = game.add.sprite(1000,370,"ulap3");
    game.physics.arcade.enable(ulap3);
    ulap3.body.immovable = true;

    ulap4 = game.add.sprite(180,260,"ulap4");
    game.physics.arcade.enable(ulap4);
    ulap4.body.immovable = true;

    ulap5 = game.add.sprite(500,70,"ulap5");
    game.physics.arcade.enable(ulap5);
    ulap5.body.immovable = true;

    player.animations.add('walk-right',[1,2,3,4,5,6],0,true);
    player.animations.add('walk-left',[12,11,10,9,8,7],0,true);
    //player.animations.add('jump',[12,13,14,15],0,true);

    player2.animations.add('walk-right',[8,9,10,11],7,true);
    player2.animations.add('walk-left',[7,6,5,4],7,true);
    player2.animations.add('walk-down',[0,1,2,3],7,true);

    player3.animations.add('walk-right',[8,9,10,11],7,true);
    player3.animations.add('walk-left',[7,6,5,4],7,true);
    player3.animations.add('walk-down',[0,1,2,3],7,true);

    
    buttonLeft = game.add.button(60,650,"leftButton",this.walkLeft);
    buttonRight = game.add.button(210,650,"rightButton",this.walkRight);
    buttonjump = game.add.button(1020,650,"jumpButton",this.jump);

    kansyon =game.add.audio("music",1,true);
    kansyon.Loop =true;
    kansyon.play();

    //keyboard = game.input.keyboard.createCursorKeys();

    game.physics.arcade.enable(player);
    player.body.collideWorldBounds = true;
    player.body.gravity.y = 1000;

    game.physics.arcade.enable(player2);
    //player2.body.collideWorldBounds = true;
    //player2.body.gravity.y = 1000;
    player2.body.collideWorldBounds = true;
    player2.body.velocity.x=-200;
    player2.animations.play('walk-down');
    player2.body.bounce.x=1;

    game.physics.arcade.enable(player3);
    player3.body.collideWorldBounds = true;
    player3.body.velocity.x=-300;
    player3.animations.play('walk-down');
    player3.body.bounce.x=1;


    this.pauseButton = this.game.add.sprite(1100, 20, 'pauseButton');
    this.pauseButton.inputEnabled = true;
    this.pauseButton.events.onInputUp.add(function () {this.game.paused = true;},this);
    this.game.input.onDown.add(function () {if(this.game.paused)this.game.paused = false;},this); 

    
    stateText = game.add.text(170,450,' ', { font: '30px Times New Roman', fill: 'black' });
    stateText.anchor.setTo(0.5, 0.5);
    stateText.visible = false;
},
	update:function(){
	game.scale.pageAlignVertically = true;
    game.scale.pageAlignHorizontally = true;
    game.scale.setShowAll();
    game.scale.refresh();
    
    game.physics.arcade.collide(player,platform1);
    game.physics.arcade.collide(player,platform2);
    game.physics.arcade.collide(player,platform3);
    game.physics.arcade.collide(player,platform4);
    game.physics.arcade.collide(player,platform5);

    game.physics.arcade.collide(player2,platform1);
    game.physics.arcade.collide(player2,platform2);
    game.physics.arcade.collide(player2,platform3);
    game.physics.arcade.collide(player2,platform4);
    game.physics.arcade.collide(player2,platform5);

    game.physics.arcade.collide(player3,platform1);
    game.physics.arcade.collide(player3,platform2);
    game.physics.arcade.collide(player3,platform3);
    game.physics.arcade.collide(player3,platform4);
    game.physics.arcade.collide(player3,platform5);

    game.physics.arcade.collide(player,player2,this.touchPlayer);
    game.physics.arcade.collide(player,player2);

    game.physics.arcade.collide(player,player3,this.touchPlayer2);
    game.physics.arcade.collide(player,player3);

    game.physics.arcade.overlap(player,ulap1,this.touchUlap1);
    game.physics.arcade.collide(player,ulap1);
    game.physics.arcade.overlap(player,ulap2,this.touchUlap2);
    game.physics.arcade.collide(player,ulap2);
    game.physics.arcade.overlap(player,ulap3,this.touchUlap3);
    game.physics.arcade.collide(player,ulap3);
    game.physics.arcade.overlap(player,ulap4,this.touchUlap4);
    game.physics.arcade.collide(player,ulap4);
    game.physics.arcade.overlap(player,ulap5,this.touchUlap5);
    game.physics.arcade.collide(player,ulap5);
    

},
walkLeft:function (){
    buttonLeft.frame = 1;
        player.body.velocity.x = -500;
        player.animations.play('walk-left');
        
    setTimeout(function(){
        buttonLeft.frame = 0;
        player.body.velocity.x = 0;
        player.animations.stop();
    },100)
},
    walkRight:function (){
    buttonRight.frame = 1;
        player.body.velocity.x = 500;
        player.animations.play('walk-right');
        
    setTimeout(function(){
        buttonRight.frame = 0;
        player.body.velocity.x = 0;
        player.animations.stop();
    },100)
},
    jump:function (){
    buttonjump.frame = 1;
        player.body.velocity.y = -650;
        player.animations.play('jump');
        
    setTimeout(function(){
        buttonjump.frame = 0;
        player.body.velocity.x = 0;
        player.animations.stop();
    },100)
},
    touchPlayer:function(player,player2){
        player.kill();
        game._paused = true

        kansyon.stop();
    
        gamepage=game.add.image(0,0,"gameover");

        restartButton=game.add.button(520,500,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

},
	touchPlayer2:function(player,player3){
        player.kill();
        game._paused = true

        kansyon.stop();
    
        gamepage=game.add.image(0,0,"gameover");

        restartButton=game.add.button(520,500,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

},
    touchUlap1:function(player,ulap){

        score  += 5;
        scoreText.text = 'Score:  ' + score;
        ulap1.kill();

        if(score>=25) {
           winnerpage=game.add.image(0,0,"winner");

           kansyon.stop();
        
            restartButton=game.add.button(520,500,"restart",restartB,this);
            function restartB() {
            winnerpage.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }

        }
},
    touchUlap2:function(player,ulap){

        score  += 5;
        scoreText.text = 'Score:  ' + score;
        ulap2.kill();

        if(score>=25) {
           winnerpage=game.add.image(0,0,"winner");

           kansyon.stop();
        
            restartButton=game.add.button(520,500,"restart",restartB,this);
            function restartB() {
            winnerpage.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }

        }
},
    touchUlap3:function(player,ulap){

        score  += 5;
        scoreText.text = 'Score:  ' + score;
        ulap3.kill();

        if(score>=25) {
           winnerpage=game.add.image(0,0,"winner");

           kansyon.stop();
        
            restartButton=game.add.button(520,500,"restart",restartB,this);
            function restartB() {
            winnerpage.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }

        }
},
    touchUlap4:function(player,ulap){

        score  += 5;
        scoreText.text = 'Score:  ' + score;
        ulap4.kill();

        if(score>=25) {
           winnerpage=game.add.image(0,0,"winner");

           kansyon.stop();
        
            restartButton=game.add.button(520,500,"restart",restartB,this);
            function restartB() {
            winnerpage.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }

        }
},
    touchUlap5:function(player,ulap){

        score  += 5;
        scoreText.text = 'Score:  ' + score;
        ulap5.kill();

        if(score>=25) {
           winnerpage=game.add.image(0,0,"winner");

           kansyon.stop();
        
            restartButton=game.add.button(520,500,"restart",restartB,this);
            function restartB() {
            winnerpage.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }

        }
},
    restart:function() {
   
    window.location.href=window.location.href;
    stateText.visible = false;
},
loopAudio:function(time){
    setInterval(function(){
        kansyon.play();
    },time)
},
}


winGame = {
	
}
loseGame = {
	
}

